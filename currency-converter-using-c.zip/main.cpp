/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    char startValue;
    char SelectAgain;
    float converter(void);
    start:
    cout<<" *** Welcome to Currency Converter Application  *** "<<endl;
    cout<<" PLease folloe the instruction "<<endl;
    cout<<" You can have currencies doller, rupees,euro,pounds "<<endl;
    cout<<" You can type a,b,c,d respectively four currencies doller,rupees,euro,pounds "<<endl;
    cout<<" Enter currency one which you want to convert "<<endl;
    cout<<" Enter the value for currency one value "<<endl;
    cout<<" Enter currency two  in which you want to convert currency one "<<endl;
    cout<<" (a) doller (b) rupees (c) euro (d) pounds "<<endl;
    cout<<" Please press S to start "<<endl;
    SelectChoice:
    cin>>startValue;
    if(startValue == 's' || startValue == 'S'){
        float FinalValue = converter();
       cout<<"result is "<<FinalValue<<endl;
       cout<<" do you want use application again? y or n "<<endl;
       typeAgain:
       cin>>SelectAgain;
       if(SelectAgain == 'y' || SelectAgain == 'Y'){
           goto start;
       }
       else if(SelectAgain == 'n' || SelectAgain == 'N'){
           cout<<" Thank you for using our application ! "<<endl;
       }
       else{
           cout<<" You have entered wrong value, please type again "<<endl;
           goto typeAgain;
       }
    }
    else{
        cout<<"you have entered wrong value, please type s"<<endl;
             goto SelectChoice;
        }
    }
    float converter(){
        char CurrName1;
        char CurrName2;
        float Currency1;
        float Currency2;
        CurrencyLevel:

        cout<<" Enter Currency one Name "<<endl;
        cin>>CurrName1;
        cout<<" Enter Currency one Value "<<endl;
        cin>>Currency1;
        
        switch(CurrName1){
            // Doller coverting case a
            case 'a':
                CurrencyLevel1:
                
                cout<<" Enter Currency Name two  "<<endl;
                cin>>CurrName2;
                if(CurrName2 == 'a' || CurrName2 == 'A'){
                    Currency2 = Currency1 * 1;
                }
                else if(CurrName2 == 'b' || CurrName2 == 'B'){
                    Currency2 = Currency1 * 82.90;
                }
                else if(CurrName2 == 'c' || CurrName2 == 'C'){
                     Currency2 = Currency1 * 0.85;
                }
                else if(CurrName2 == 'd' || CurrName2 == 'D'){
                     Currency2 = Currency1 * 0.72;
                }
                else{
                    cout<<" You have entered wrong value, please type again "<<endl;
                    goto CurrencyLevel1;
                }
                break;
                
                // Rupees  coverting case b
            case 'b':
                CurrencyLevel2:
                
                cout<<" Enter Currency Name two  "<<endl;
                cin>>CurrName2;
                if(CurrName2 == 'a' || CurrName2 == 'A'){
                    Currency2 = Currency1 * 0.01;
                }
                else if(CurrName2 == 'b' || CurrName2 == 'B'){
                    Currency2 = Currency1 * 1;
                }
                else if(CurrName2 == 'c' || CurrName2 == 'C'){
                     Currency2 = Currency1 * 0.01;
                }
                else if(CurrName2 == 'd' || CurrName2 == 'D'){
                     Currency2 = Currency1 * 0.009;
                }
                else{
                    cout<<" You have entered wrong value, please type again "<<endl;
                    goto CurrencyLevel2;
                }
                break;
                
                 // Euro  coverting case c
            case 'c':
                CurrencyLevel3:
                
                cout<<" Enter Currency Name two  "<<endl;
                cin>>CurrName2;
                if(CurrName2 == 'a' || CurrName2 == 'A'){
                    Currency2 = Currency1 * 1.16;
                }
                else if(CurrName2 == 'b' || CurrName2 == 'B'){
                    Currency2 = Currency1 * 86.37;
                }
                else if(CurrName2 == 'c' || CurrName2 == 'C'){
                     Currency2 = Currency1 * 1;
                }
                else if(CurrName2 == 'd' || CurrName2 == 'D'){
                     Currency2 = Currency1 * 0.85;
                }
                else{
                    cout<<" You have entered wrong value, please type again "<<endl;
                    goto CurrencyLevel3;
                }
                break;
                
                  // pounds  coverting case d
            case 'd':
                CurrencyLevel4:
                
                cout<<" Enter Currency Name two  "<<endl;
                cin>>CurrName2;
                if(CurrName2 == 'a' || CurrName2 == 'A'){
                    Currency2 = Currency1 * 1.37;
                }
                else if(CurrName2 == 'b' || CurrName2 == 'B'){
                    Currency2 = Currency1 * 101.20;
                }
                else if(CurrName2 == 'c' || CurrName2 == 'C'){
                     Currency2 = Currency1 * 1.17;
                }
                else if(CurrName2 == 'd' || CurrName2 == 'D'){
                     Currency2 = Currency1 * 1;
                }
                else{
                    cout<<" You have entered wrong value, please type again "<<endl;
                    goto CurrencyLevel4;
                }
                break;
                
            default:{
                cout<<" You have entered wrong value, please type again "<<endl;
                    goto CurrencyLevel;
                    break;
            }
        }
        
    return Currency2;
}
 

